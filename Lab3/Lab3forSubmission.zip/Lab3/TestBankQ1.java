
public class TestBankQ1 {

	public static void main(String[] args) {
		String [] bankArgs = {"q1.txt"};
		Banker.main(bankArgs);
	}

}
